import React,{Component} from 'react'

class Subject extends Component {
  render(){
    return (
      <div>
      </div>
    );
  }
}

  export default Subject;